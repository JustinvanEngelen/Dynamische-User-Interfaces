var partijen =["D66","CDA","BBB","VVD","SGP","PVV"];
var score = [0,0,0,0,0,0];

for (let i = 0; i < partijen.length; i++) {
  const button = document.createElement('button');
  button.id = `button${i}`;
  button.textContent = partijen[i];
  button.addEventListener('click', () => clickBtn(i));
  container.appendChild(button);
}

const submit = document.createElement('button');
submit.id = 'submit';
submit.textContent = 'Submit';
submit.addEventListener('click', () => submitBtn());
container.appendChild(submit);


function clickBtn(i) {
    score[i] += 1;
    }

//make a function that shows the results of each party as a display and removes the buttons and shows the winner and everytime it is a draw it shows a draw message and removes the winner message if it is a draw and its 2 or more parties with the same amount of votes it shows a draw message and removes the winner message
function submitBtn() {
    let maxScore = Math.max(...score);
    let winnerCount = score.filter((s) => s === maxScore).length;

    for (let i = 0; i < partijen.length; i++) {
        const display = document.createElement('div');
        display.id = `display${i}`;
        display.textContent = `${partijen[i]}: ${score[i]} stemmen`;
        container.appendChild(display);
        const button = document.getElementById(`button${i}`);
        button.remove();
    }
    
    const submit = document.getElementById('submit');
    submit.remove();

    if (winnerCount === 1) {
        const winner = document.createElement('div');
        winner.id = 'winner';
        winner.textContent = `De winnaar is ${partijen[score.indexOf(maxScore)]}!`;
        container.appendChild(winner);
    } else {
        const draw = document.createElement('div');
        draw.id = 'draw';
        draw.textContent = `Het is een gelijkspel!`;
        container.appendChild(draw);
    }
}

    





